<template>
    <MainPageHero />
   <MainPageSlider />
    <MainPageBenefits />
    <MainPageTariffs />
     <MainPageJoinUs />

    <Aside />
</template>