<script setup>

</script>

<template>
    <Header />
    <main class="">
        <NuxtPage></NuxtPage>
    </main>
    <Footer />
</template>

<style lang="scss">
@import '@/assets/reset.min.scss';
@import '@/assets/global.scss';
</style>