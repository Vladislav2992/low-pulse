<script setup>
import Operation from './Operation.vue';
</script>
<template>
    <section class="hero">
        <div class="container">           
            <p class="description">простое и надежное решение</p>
            <h1 class="hero__title">Low Pulse - мониторинг вашего сайта или приложения 24/7</h1>
            <div class="input-wrapper">
                <input type="text" class="input" placeholder="Ваш сайт">
                <button class="hook">Подключить мониторинг</button>
            </div>
            <div class="services__wrapper">
                <ul class="services">
                    <li class="service">
                        <div class="picture">
                            <svg width="37" height="38" viewBox="0 0 37 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.15" d="M25.6156 20.9411C29.6166 22.0132 33.925 19.4857 32.9476 15.4606C32.8429 15.0291 32.7187 14.6012 32.5751 14.1784C31.6215 11.3691 29.8563 8.90568 27.5026 7.09966C25.149 5.29363 22.3126 4.22611 19.3522 4.03207C16.3919 3.83804 13.4404 4.52622 10.8712 6.00958C8.30193 7.49294 6.23024 9.70486 4.9181 12.3656C3.60595 15.0264 3.11228 18.0165 3.49952 20.9578C3.88675 23.8992 5.1375 26.6596 7.09359 28.8901C7.38803 29.2259 7.69645 29.5473 8.01776 29.8538C11.015 32.7129 15.358 30.2454 16.43 26.2444C17.5021 22.2434 21.6146 19.869 25.6156 20.9411Z" fill="url(#paint0_radial_4032_120)"/>
                            <path d="M8.56937 21.3502L7.9978 20.8646L7.9978 20.8646L8.56937 21.3502ZM9.66845 18.7982L8.92321 18.7138L9.66845 18.7982ZM26.3316 18.7982L27.0768 18.7138L26.3316 18.7982ZM27.4306 21.3502L28.0022 20.8646V20.8646L27.4306 21.3502ZM25.9005 14.9927L25.1552 15.0771V15.0771L25.9005 14.9927ZM10.0995 14.9927L10.8448 15.0771L10.0995 14.9927ZM22.4523 28.0133C22.5977 27.6255 22.4011 27.1932 22.0132 27.0478C21.6253 26.9025 21.1931 27.099 21.0477 27.4869L22.4523 28.0133ZM14.9523 27.4869C14.8069 27.099 14.3747 26.9025 13.9868 27.0478C13.5989 27.1932 13.4023 27.6255 13.5477 28.0133L14.9523 27.4869ZM25.7123 24.5001H10.2877V26.0001H25.7123V24.5001ZM25.1552 15.0771L25.5863 18.8827L27.0768 18.7138L26.6457 14.9082L25.1552 15.0771ZM10.4137 18.8827L10.8448 15.0771L9.35431 14.9082L8.92321 18.7138L10.4137 18.8827ZM9.14093 21.8358C9.84734 21.0043 10.29 19.9743 10.4137 18.8827L8.92321 18.7138C8.83264 19.5134 8.50882 20.2631 7.9978 20.8646L9.14093 21.8358ZM25.5863 18.8827C25.71 19.9743 26.1527 21.0043 26.8591 21.8358L28.0022 20.8646C27.4912 20.2631 27.1674 19.5134 27.0768 18.7138L25.5863 18.8827ZM10.2877 24.5001C9.00855 24.5001 8.23478 22.9023 9.14093 21.8358L7.9978 20.8646C6.32044 22.8389 7.64348 26.0001 10.2877 26.0001V24.5001ZM25.7123 26.0001C28.3565 26.0001 29.6796 22.8389 28.0022 20.8646L26.8591 21.8358C27.7652 22.9023 26.9915 24.5001 25.7123 24.5001V26.0001ZM26.6457 14.9082C26.137 10.4176 22.4351 7.00012 18 7.00012V8.50012C21.6375 8.50012 24.7285 11.3098 25.1552 15.0771L26.6457 14.9082ZM10.8448 15.0771C11.2715 11.3098 14.3625 8.50012 18 8.50012V7.00012C13.5649 7.00012 9.86302 10.4176 9.35431 14.9082L10.8448 15.0771ZM21.0477 27.4869C20.6158 28.6393 19.4308 29.5001 18 29.5001V31.0001C20.0317 31.0001 21.7925 29.7739 22.4523 28.0133L21.0477 27.4869ZM18 29.5001C16.5692 29.5001 15.3842 28.6393 14.9523 27.4869L13.5477 28.0133C14.2075 29.7739 15.9683 31.0001 18 31.0001V29.5001Z" fill="white"/>
                            <defs>
                            <radialGradient id="paint0_radial_4032_120" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(18.3712 19) rotate(105) scale(15)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                        </div>
                        <p>Встроенные уведомления</p>
                    </li>
                    <li class="service">
                        <div class="picture">
                            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <mask id="path-1-inside-1_4034_183" fill="white">
                                <rect x="6" y="9" width="24" height="8" rx="1.16129" />
                            </mask>
                            <rect x="6" y="9" width="24" height="8" rx="1.16129" stroke="white" stroke-width="2.55484" mask="url(#path-1-inside-1_4034_183)" />
                            <mask id="path-2-inside-2_4034_183" fill="white">
                                <rect x="6" y="20" width="24" height="8" rx="1.16129" />
                            </mask>
                            <rect x="6" y="20" width="24" height="8" rx="1.16129" stroke="white" stroke-width="2.55484" mask="url(#path-2-inside-2_4034_183)" />
                            <circle cx="11" cy="13" r="1" fill="white" />
                            <circle cx="11" cy="24" r="1" fill="white" />
                            <circle cx="14" cy="13" r="1" fill="white" />
                            <circle cx="14" cy="24" r="1" fill="white" />
                            <rect x="19" y="12" width="7" height="1" fill="white" />
                            <rect x="19" y="23" width="7" height="1" fill="white" />
                            <path opacity="0.15" d="M25.5316 24.6662C29.6974 27.0713 35.2899 25.5312 35.4034 20.7223C35.4155 20.2068 35.4048 19.6896 35.3709 19.1721C35.1456 15.7343 33.9059 12.4404 31.8085 9.70716C29.7112 6.97388 26.8505 4.92391 23.5881 3.81648C20.3257 2.70905 16.8082 2.5939 13.4804 3.48559C10.1526 4.37728 7.16387 6.23576 4.89228 8.82602C2.62068 11.4163 1.1682 14.622 0.718511 18.0377C0.26882 21.4535 0.842114 24.9259 2.3659 28.0158C2.59526 28.4809 2.8446 28.9342 3.1129 29.3745C5.61559 33.4824 11.2289 32.02 13.634 27.8542C16.0391 23.6884 21.3659 22.2611 25.5316 24.6662Z" fill="url(#paint0_radial_4034_183)" />
                            <defs>
                                <radialGradient id="paint0_radial_4034_183" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.9888 20.3114) rotate(120) scale(17.4194)">
                                <stop offset="0.47904" stop-color="white" stop-opacity="0" />
                                <stop offset="1" stop-color="white" />
                                </radialGradient>
                            </defs>
                            </svg>
                        </div>
                        <p>Кастомизируемый домен</p>
                    </li>
                    <li class="service">
                        <div class="picture">
                            <svg width="35" height="36" viewBox="0 0 35 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.15" d="M24.9313 18.7524C29.244 19.1679 33.2527 15.8169 31.5496 11.8329C31.3671 11.4058 31.1651 10.9859 30.9441 10.5744C29.4754 7.84075 27.2291 5.60398 24.4892 4.14696C21.7494 2.68993 18.639 2.0781 15.5514 2.38882C12.4638 2.69955 9.53762 3.91888 7.143 5.89262C4.74838 7.86636 2.99282 10.5059 2.09832 13.4773C1.20382 16.4488 1.21055 19.6188 2.11767 22.5865C3.02478 25.5542 4.79154 28.1862 7.19452 30.1497C7.55622 30.4453 7.92989 30.7237 8.31426 30.9844C11.8998 33.4168 15.9545 30.1216 16.37 25.8089C16.7856 21.4962 20.6186 18.3369 24.9313 18.7524Z" fill="url(#paint0_radial_4039_99)"/>
                            <path d="M12.422 29C14.4864 29 16.2205 27.5923 16.7075 25.6889C16.8581 25.1001 17.3388 24.6 17.9494 24.6H25.6878M12.422 29C9.97977 29 8 27.0301 8 24.6V10.3C8 8.47746 9.48483 7 11.3165 7H22.3713C24.203 7 25.6878 8.47746 25.6878 10.3V24.6M12.422 29H25.6878C27.7523 29 29.4863 27.5923 29.9733 25.6889C30.1239 25.1001 29.6148 24.6 29.0043 24.6H25.6878M21.2659 12.5H12.422M16.8439 18H12.422" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                            <defs>
                            <radialGradient id="paint0_radial_4039_99" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.1224 18) rotate(95.5033) scale(15.6901)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                        </div>
                        <p>Включена страница статуса</p>
                    </li>
                    <li class="service">
                        <div class="picture">
                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.15" d="M22.5 15C26.6421 15 30.1496 11.4436 28.1637 7.80854C27.9508 7.41886 27.7201 7.03774 27.472 6.66645C25.8238 4.19971 23.4811 2.27712 20.7403 1.14181C17.9994 0.0064925 14.9834 -0.290558 12.0736 0.288221C9.16393 0.866999 6.49119 2.29561 4.3934 4.3934C2.29561 6.49119 0.866999 9.16393 0.288221 12.0736C-0.290558 14.9834 0.00649254 17.9994 1.14181 20.7403C2.27712 23.4811 4.19971 25.8238 6.66645 27.472C7.03774 27.7201 7.41886 27.9508 7.80854 28.1637C11.4436 30.1496 15 26.6421 15 22.5C15 18.3579 18.3579 15 22.5 15Z" fill="url(#paint0_radial_4117_107)"/>
                            <path d="M5 16.25H4.25V17.75H5V16.25ZM25 17.75H25.75V16.25H25V17.75ZM12 24.25C11.5858 24.25 11.25 24.5858 11.25 25C11.25 25.4142 11.5858 25.75 12 25.75V24.25ZM18 25.75C18.4142 25.75 18.75 25.4142 18.75 25C18.75 24.5858 18.4142 24.25 18 24.25V25.75ZM15.75 21C15.75 20.5858 15.4142 20.25 15 20.25C14.5858 20.25 14.25 20.5858 14.25 21H15.75ZM8 5.75H22V4.25H8V5.75ZM24.25 8V18H25.75V8H24.25ZM22 20.25H8V21.75H22V20.25ZM5.75 18V8H4.25V18H5.75ZM8 20.25C6.75736 20.25 5.75 19.2426 5.75 18H4.25C4.25 20.0711 5.92893 21.75 8 21.75V20.25ZM24.25 18C24.25 19.2426 23.2426 20.25 22 20.25V21.75C24.0711 21.75 25.75 20.0711 25.75 18H24.25ZM22 5.75C23.2426 5.75 24.25 6.75736 24.25 8H25.75C25.75 5.92893 24.0711 4.25 22 4.25V5.75ZM8 4.25C5.92893 4.25 4.25 5.92893 4.25 8H5.75C5.75 6.75736 6.75736 5.75 8 5.75V4.25ZM5 17.75H25V16.25H5V17.75ZM12 25.75H15V24.25H12V25.75ZM15 25.75H18V24.25H15V25.75ZM15.75 25V21H14.25V25H15.75Z" fill="white"/>
                            <defs>
                            <radialGradient id="paint0_radial_4117_107" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(15 15) rotate(90) scale(15)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                        </div>
                        <p>Мониторинг сервера</p>
                    </li>
                    <li class="service">
                        <div class="picture">
                            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.15" d="M25.5316 24.6662C29.6974 27.0713 35.2899 25.5312 35.4034 20.7223C35.4155 20.2068 35.4048 19.6896 35.3709 19.1721C35.1456 15.7343 33.9059 12.4404 31.8085 9.70716C29.7112 6.97388 26.8505 4.92391 23.5881 3.81648C20.3257 2.70905 16.8082 2.5939 13.4804 3.48559C10.1526 4.37728 7.16387 6.23576 4.89228 8.82602C2.62068 11.4163 1.1682 14.622 0.718511 18.0377C0.26882 21.4535 0.842114 24.9259 2.3659 28.0158C2.59526 28.4809 2.8446 28.9342 3.1129 29.3745C5.61559 33.4824 11.2289 32.02 13.634 27.8542C16.0391 23.6884 21.3659 22.2611 25.5316 24.6662Z" fill="url(#paint0_radial_4117_122)"/>
                            <circle cx="18" cy="26.75" r="1.25" fill="white"/>
                            <path d="M29.8063 12.5824C26.6941 9.73628 22.5498 8 18 8C13.4502 8 9.30594 9.73628 6.19366 12.5824M25.7986 17.3917C23.7763 15.4462 21.0278 14.25 18 14.25C14.9722 14.25 12.2237 15.4462 10.2014 17.3917M21.7745 22.2206C20.8578 21.1664 19.5067 20.5 18 20.5C16.4933 20.5 15.1422 21.1664 14.2255 22.2206" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                            <defs>
                            <radialGradient id="paint0_radial_4117_122" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.9888 20.3114) rotate(120) scale(17.4194)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                        </div>
                        <p>Кастомизируемый домен</p>
                    </li>
                    <li class="service">
                        <div class="picture">
                            <svg width="35" height="36" viewBox="0 0 35 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.15" d="M24.9313 18.7524C29.244 19.1679 33.2527 15.8169 31.5496 11.8329C31.3671 11.4058 31.1651 10.9859 30.9441 10.5744C29.4754 7.84075 27.2291 5.60398 24.4892 4.14696C21.7494 2.68993 18.639 2.0781 15.5514 2.38882C12.4638 2.69955 9.53762 3.91888 7.143 5.89262C4.74838 7.86636 2.99282 10.5059 2.09832 13.4773C1.20382 16.4488 1.21055 19.6188 2.11767 22.5865C3.02478 25.5542 4.79154 28.1862 7.19452 30.1497C7.55622 30.4453 7.92989 30.7237 8.31426 30.9844C11.8998 33.4168 15.9545 30.1216 16.37 25.8089C16.7856 21.4962 20.6186 18.3369 24.9313 18.7524Z" fill="url(#paint0_radial_4117_142)"/>
                            <path d="M17.5 12.6666V13.875M17.5 16.8958V22.3333M17.5 29.5833C24.1734 29.5833 29.5833 24.1734 29.5833 17.5C29.5833 10.8265 24.1734 5.41663 17.5 5.41663C10.8265 5.41663 5.41663 10.8265 5.41663 17.5C5.41663 24.1734 10.8265 29.5833 17.5 29.5833Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <defs>
                            <radialGradient id="paint0_radial_4117_142" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.1224 18) rotate(95.5033) scale(15.6901)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                        </div>
                        <p>Проишествия</p>
                    </li>
                </ul>
            </div>

            <Operation />
        </div>
    </section>
</template>
<style lang="scss" scoped>
.hero {
    height: 100vh;
    min-height: 720px;
    background: var(--blue) url('../../assets/img/main-bg.png') no-repeat;
    background-size: cover;
    border-radius: 0 0 40px 50px;
    overflow: hidden; 
    position: relative;

    &::before {
        content: '';
        position: absolute;
        top: 110px;
        left: 0;
        right: 0;
        background: url('../../assets/img/graph.svg') no-repeat;
        background-size: cover;
        height: 100%;
    }
    &::after {
        content: '';
        position: absolute;
        bottom: 5px;
        left: 0;
        right: 0;
        background: url('../../assets/img/puls-line.svg') no-repeat;
        background-position: -166px;
        background-size: cover;
        height: 80px;
    }

    .container {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        height: 100%;
        position: relative;
        max-width: 1070px;
    }
}
.description {
    font-size: clamp(16px, 4vw, 20px);
    color: var(--white);
    font-weight: 600;
    margin-bottom: 10px;
}
.hero__title {
    font-family: 'Jost', sans-serif;
    font-size: clamp(32px, 7vw, 72px);
    color: var(--white);
    font-weight: 600;
    margin-bottom: 20px;
    line-height: 100%;
    margin-bottom: 40px;
}
.input-wrapper {    
    border-radius: 42px;
    width: 820px;
    height: 52px;    
    background: #232642, var(--white);
    position: relative;
    margin-bottom: 40px;
}
.input {
    border: none;
    border-radius: 42px;
    padding: 14px 30px;
    width: 100%;
    height: 100%;
    border: 1px solid rgba(102, 110, 170, 0.3);
    box-shadow: 0 5px 17px 0 rgba(255, 255, 255, 0.2);
}

.hook {
    position: absolute;
    padding: 12px 36px;
    font-size: 15px;
    font-weight: 600;
    color: var(--blue);
    width: fit-content;
    border: 1px solid rgba(102, 110, 170, 0.3);
    border-radius: 42px;
    right: 5px;
    bottom: 4px;
}

.services {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px 15px;
    max-width: 820px;
    margin: 0 auto;
}

.service {
    padding: 10px 20px;
    border: 1px solid #fff;
    border-radius: 40px;
    display: flex;
    align-items: center;
    gap: 15px;
    color: var(--white);
    font-size: 15px;
    font-weight: 700;
    text-align: left;
    line-height: 130%;
}
@media (max-width: 850px) {
    .hero {
        border-radius: 0;
        min-height: 500px;
        height: auto;
        padding: 50px 0;

        &::after {
            height: 31px;
        }
    }
    .input-wrapper {
        width: 100%;
    }
}
@media (max-width: 760px) {
    .hero {
        margin-bottom: 33px;
    }
    .input-wrapper {
        display: flex;
        flex-direction: column;
        gap: 10px;
        height: auto;
        margin-bottom: 20px;
    }
    .hook {
        position: static;
        width: 100%;
    }
    
    .services {
        grid-template-columns: 1fr 1fr;
        gap: 10px 5px;
    }
    .service {
        padding: 10px;
        font-size: 13px;
        gap: 10px;

        svg {
            width: 27px;
            height: 27px;
        }
    }
}
</style>