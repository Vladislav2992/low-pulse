<template>
    <section class="benefits">
        <div class="container">
            <h2 class="section__title">LowPulse: Лучший выбор для мониторинга вашего сайта</h2>
            <p class="benefits__desription">LowPulse - это уникальный инструмент для мониторинга вашего сайта, который предоставляет надежное и всестороннее понимание его состояния и производительности. </p>

            <div class="benefits__wrapper">
                <div class="benefit">
                    <div class="benefit__text">
                        <div class="benefit__title">
                            <svg width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect width="35" height="35" rx="5" fill="#1F233E"/>
                            <path opacity="0.3" d="M25.7642 22.9767C28.6411 24.6376 32.4641 23.6155 32.87 20.3185C32.9844 19.3896 33.0121 18.4477 32.9503 17.505C32.7563 14.5453 31.689 11.7095 29.8834 9.35641C28.0778 7.00328 25.6149 5.23843 22.8063 4.28502C19.9977 3.33161 16.9694 3.23248 14.1044 4.00015C11.2394 4.76782 8.66638 6.36782 6.71073 8.59782C4.75507 10.8278 3.5046 13.5877 3.11746 16.5283C2.73031 19.469 3.22387 22.4585 4.53572 25.1186C4.95359 25.966 5.4485 26.7678 6.012 27.515C8.0121 30.1674 11.834 29.1411 13.4949 26.2642L14.9784 23.6948C16.6393 20.8179 20.318 19.8323 23.1948 21.4932L25.7642 22.9767Z" fill="url(#paint0_radial_4133_132)"/>
                            <path d="M7.5 19.25H6.75V20.75H7.5V19.25ZM27.5 20.75H28.25V19.25H27.5V20.75ZM14.5 27.25C14.0858 27.25 13.75 27.5858 13.75 28C13.75 28.4142 14.0858 28.75 14.5 28.75V27.25ZM20.5 28.75C20.9142 28.75 21.25 28.4142 21.25 28C21.25 27.5858 20.9142 27.25 20.5 27.25V28.75ZM18.25 24C18.25 23.5858 17.9142 23.25 17.5 23.25C17.0858 23.25 16.75 23.5858 16.75 24H18.25ZM10.5 8.75H24.5V7.25H10.5V8.75ZM26.75 11V21H28.25V11H26.75ZM24.5 23.25H10.5V24.75H24.5V23.25ZM8.25 21V11H6.75V21H8.25ZM10.5 23.25C9.25736 23.25 8.25 22.2426 8.25 21H6.75C6.75 23.0711 8.42893 24.75 10.5 24.75V23.25ZM26.75 21C26.75 22.2426 25.7426 23.25 24.5 23.25V24.75C26.5711 24.75 28.25 23.0711 28.25 21H26.75ZM24.5 8.75C25.7426 8.75 26.75 9.75736 26.75 11H28.25C28.25 8.92893 26.5711 7.25 24.5 7.25V8.75ZM10.5 7.25C8.42893 7.25 6.75 8.92893 6.75 11H8.25C8.25 9.75736 9.25736 8.75 10.5 8.75V7.25ZM7.5 20.75H27.5V19.25H7.5V20.75ZM14.5 28.75H17.5V27.25H14.5V28.75ZM17.5 28.75H20.5V27.25H17.5V28.75ZM18.25 28V24H16.75V28H18.25Z" fill="white"/>
                            <defs>
                            <radialGradient id="paint0_radial_4133_132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.9858 18.4858) rotate(120) scale(14.9966)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                            <h3 class="title">Мониторинг сервера</h3>
                        </div>
                            <p>Следите за состоянием ваших ресурсов (CPU, Disk, Ram... и т.д.) на ваших Linux - серверах.</p>
                            <button class="btn">Начать бесплатно</button>
                    </div>
                    <div class="benefit__img">
                        <img src="/benefits/1.png" alt="">
                    </div>
                </div>
                <div class="benefit">
                    <div class="benefit__text">
                        <div class="benefit__title">
                            <svg width="35" height="36" viewBox="0 0 35 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect y="0.292969" width="35" height="35" rx="4.60526" fill="#1F233E"/>
                            <path opacity="0.3" d="M23.0356 22.4852C26.0978 24.2531 30.2086 23.121 30.292 19.5862C30.301 19.2072 30.2931 18.827 30.2682 18.4466C30.1025 15.9196 29.1913 13.4984 27.6496 11.4893C26.1079 9.48013 24.0051 7.97327 21.607 7.15923C19.2089 6.34519 16.6233 6.26055 14.1772 6.916C11.731 7.57145 9.5341 8.93756 7.86432 10.8416C6.19455 12.7456 5.12688 15.102 4.79633 17.6128C4.46577 20.1236 4.88718 22.676 6.00726 24.9473C6.17586 25.2892 6.35915 25.6224 6.55636 25.9461C8.39601 28.9657 12.5222 27.8907 14.2901 24.8286C16.058 21.7664 19.9735 20.7173 23.0356 22.4852Z" fill="url(#paint0_radial_4133_196)"/>
                            <ellipse cx="17.5" cy="24.793" rx="1.04167" ry="1" fill="white"/>
                            <path d="M27.3386 13.4589C24.745 11.182 21.2915 9.79297 17.5 9.79297C13.7085 9.79297 10.2549 11.182 7.66138 13.4589M23.9988 17.3063C22.3136 15.7499 20.0232 14.793 17.5 14.793C14.9768 14.793 12.6864 15.7499 11.0012 17.3063M20.6454 21.1695C19.8815 20.3261 18.7556 19.793 17.5 19.793C16.2444 19.793 15.1185 20.3261 14.3546 21.1695" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                            <defs>
                            <radialGradient id="paint0_radial_4133_196" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.4912 19.2841) rotate(120) scale(12.8044)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                            <h3 class="title">Страница статуса</h3>
                        </div>
                            <p>Будьте открыты с вашими посетителями и красиво демонстрируйте статистику вашего сайта.</p>
                            <button class="btn">Начать бесплатно</button>
                    </div>
                    <div class="benefit__img">
                        <img src="/benefits/2.png" alt="">
                    </div>
                </div>
                <div class="benefit">
                    <div class="benefit__text">
                        <div class="benefit__title">
                            <svg width="36" height="35" viewBox="0 0 36 35" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="0.5" width="35" height="35" rx="5" fill="#1F233E"/>
                            <path opacity="0.3" d="M24.292 18.1544C27.8452 18.4967 31.1457 15.7445 29.7872 12.4434C29.6148 12.0245 29.4205 11.6133 29.2047 11.2117C27.961 8.89671 26.0588 7.00252 23.7385 5.76866C21.4183 4.53479 18.7843 4.01666 16.1696 4.2798C13.5549 4.54293 11.0769 5.57551 9.04903 7.24695C7.02117 8.91839 5.53448 11.1536 4.77698 13.67C4.01948 16.1864 4.02518 18.8709 4.79337 21.384C5.56155 23.8971 7.05771 26.126 9.09265 27.7889C9.44569 28.0773 9.81219 28.3465 10.1905 28.5957C13.1715 30.5595 16.5033 27.8453 16.8456 24.292L16.8801 23.9337C17.2225 20.3805 20.3805 17.7775 23.9337 18.1199L24.292 18.1544Z" fill="url(#paint0_radial_4133_168)"/>
                            <path d="M17.6542 13V14M17.6542 16.5V21M17.6542 27C23.1771 27 27.6542 22.5228 27.6542 17C27.6542 11.4772 23.1771 7 17.6542 7C12.1314 7 7.65421 11.4772 7.65421 17C7.65421 22.5228 12.1314 27 17.6542 27Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <defs>
                            <radialGradient id="paint0_radial_4133_168" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.5 17.5) rotate(95.5033) scale(13.287)">
                            <stop offset="0.47904" stop-color="white" stop-opacity="0"/>
                            <stop offset="1" stop-color="white"/>
                            </radialGradient>
                            </defs>
                            </svg>
                            <h3 class="title">Проишествия</h3>
                        </div>
                            <p>Узнайте когда и на сколько ваши мониторы стали недоступны и получайте уведомления.</p>
                            <button class="btn">Начать бесплатно</button>
                    </div>
                    <div class="benefit__img">
                        <img src="/benefits/3.png" alt="">
                    </div>
                </div>
            </div>
            <div class="advantages">
                <div class="advantage">
                    <img src="/benefits/img-1.png" alt="">
                    <h3 class="advantage__title">Множественные локации</h3>
                    <p>Мы проверяем ваши сервера в нескольких местах по всему миру.</p>
                </div>
                <div class="advantage">
                    <img src="/benefits/img-2.png" alt="">
                    <h3 class="advantage__title">Кастомные HTTP запросы</h3>
                    <p>Метод запроса, тело запроса, базовая аутентификация и настраиваемые заголовки запроса.</p>
                </div>
                <div class="advantage">
                    <img src="/benefits/img-3.png" alt="">
                    <h3 class="advantage__title">Кастомные HTTP ответы</h3>
                    <p>Установите и ожидайте определенного ответа от ваших мониторов.</p>
                </div>
                <div class="advantage">
                    <img src="/benefits/img-4.png" alt="">
                    <h3 class="advantage__title">Уведомления на почте</h3>
                    <p>Получайте мгновенные уведомления, когда ваши отслеживаемые услуги отключаются или отключаются.</p>
                </div>
                <div class="advantage">
                    <img src="/benefits/img-5.png" alt="">
                    <h3 class="advantage__title">Проекты</h3>
                    <p>Самый простой способ классифицировать управляемые ресурсы.</p>
                </div>
                <div class="advantage">
                    <img src="/benefits/img-6.png" alt="">
                    <h3 class="advantage__title">Кастомные домены</h3>
                    <p>Подключите свой собственный домен или используйте наши предустановленные.</p>
                </div>
            </div>
        </div>
    </section>
</template>
<style lang="scss" scoped>
.section__title {
    max-width: 841px;
    margin: 0 auto;
    margin-bottom: 25px;
}

.benefits__desription {
    max-width: 841px;
    margin: 0 auto;
    margin-bottom: 100px;
    font-size: clamp(16px, 5vw, 20px);
    font-weight: 600;
    line-height: 132%;
    color: rgba(0,0,0, .5);
    text-align: center;
}

.benefit {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 100px;

    &:nth-child(2n){
        .benefit__text {
            order: 2;
        }
        .benefit__img {
            order: 1;
        }
    }
    &:nth-child(2) .benefit__img::before {
        left: 0;
    }
}

.benefit__text {
    max-width: 480px;
    order: 1;

    p {
        margin-bottom: 25px;
        line-height: 152%;
    }
}
.benefit__title {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.title {
    font-size: clamp(24px, 7vw, 32px);
    font-weight: 600;
    color: var(--blue);
}
.benefit__img {
    order: 2;
    position: relative;

    &::before {
        content: '';
        position: absolute;
        width: clamp(282px, 50vw, 456px);
        height: clamp(282px, 50vw, 456px);
        background: var(--blue);
        border-radius: 50%;
        z-index: -1;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
    }

    // &:nth-of-type(2){
    //     right: -45px;
    //     top: 11px;
    // }

}

.advantages {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px 20px;
}
.advantage {
    img {
        width: 100%;
        margin-bottom: 30px;
    }
}
.advantage__title {
    font-size: clamp(16px, 5vw, 20px);
    margin-bottom: 20px;
}

@media (max-width: 1024px) {
    .benefit {
        flex-direction: column;
        gap: 80px;

        &:nth-child(2n){
        .benefit__text {
            order: 1;
        }
        .benefit__img {
            order: 2;
        }
    }
    }
}

@media(max-width: 900px) {
    .advantages {
        grid-template-columns: repeat(2, 1fr);
    }
}
@media(max-width: 786px) {
    .advantages {
        grid-template-columns: 1fr;
        gap: 40px;

        img {
            margin-bottom: 20px;
        }
    }
    .advantage__title {
        margin-bottom: 10px;
    }
}
</style>