<template>
  <NuxtLayout></NuxtLayout>
</template>
